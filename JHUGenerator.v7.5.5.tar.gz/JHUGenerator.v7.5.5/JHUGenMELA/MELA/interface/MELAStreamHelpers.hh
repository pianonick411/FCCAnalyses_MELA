#ifndef MELASTREAMHELPERS_HH
#define MELASTREAMHELPERS_HH

#include "MELAOutputStreamer.h"


namespace MELAStreamHelpers{
  extern MELAOutputStreamer MELAout;
  extern MELAOutputStreamer MELAerr;
}


#endif
