#ifndef _TNNPDFDRIVER_HH_
#define _TNNPDFDRIVER_HH_

extern "C" {
		void nnpdfdriver_(char* gridfilename,int* lenfilename);
		void nninitpdf_(int* irep);
}

#endif
