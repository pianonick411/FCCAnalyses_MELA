#ifndef _TMODHIGGSJMATEL_HH_
#define _TMODHIGGSJMATEL_HH_

extern "C" {
  void __modhiggsj_MOD_evalamp_hj(double P[4][4], double MatElSq[11][11]);
}

#endif
