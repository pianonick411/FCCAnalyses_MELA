extern "C" void lhapdfversion_(char *version);
